<?php
/**
* @package   yoo_neo Template
* @file      default_message.php
* @version   5.5.0 August 2010
* @author    YOOtheme http://www.yootheme.com
* @copyright Copyright (C) 2007 - 2010 YOOtheme GmbH
* @license   YOOtheme Proprietary Use License (http://www.yootheme.com/license)
*/

// no direct access
defined('_JEXEC') or die('Restricted access');
?>

<h2>
	<?php echo $this->message->title ; ?>
</h2>

<p>
	<?php echo  $this->message->text ; ?>
</p>
