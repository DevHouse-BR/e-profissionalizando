<?php
include dirname(__FILE__).DIRECTORY_SEPARATOR.'component.php';
?>